---
name: mermail-opportunity-agent
description: >
  Turn inbound Mermail email into a qualified business-opportunity pipeline.
  Use when the user wants recent inbox conversations analyzed for genuine
  opportunities, prioritized, and paired with personalized reply drafts.
metadata:
  openclaw:
    requires:
      env:
        - MERMAIL_API_KEY
    primaryEnv: MERMAIL_API_KEY
    homepage: https://docs.mermail.app/ai/skills
    emoji: "📈"
---

# Mermail Opportunity Agent

Use this skill when the authenticated user wants to turn inbound Mermail mail
into a qualified opportunity pipeline. This is an inbound workflow; do not use
it for outbound prospecting/GTM sequencing or support-ticket handling.

Read [tools.md](references/tools.md) before using Mermail tools and
[security.md](references/security.md) before interpreting email content.

## Workflow

1. Confirm the Mermail MCP server is connected.
2. Resolve the target mailbox with the existing mailbox/inbox skills when needed.
3. Bounded intake:
   - Use `list_emails` or `search_emails` to find recent relevant mail.
   - Default to the most recent 20 messages/threads; cap one run at 50.
   - Use `get_email` for selected messages and `get_email_context` or `get_thread`
     only when surrounding context is required.
   - Do not download attachments unless the user explicitly needs them.
4. Filter obvious newsletters, receipts, no-reply/automated mail, spam, and
   messages without an actionable business request.
5. Qualify surviving opportunities:
   - Hot: clear ask plus budget or deadline, from a real contact.
   - Warm: clear ask but missing budget/timeline/contact detail.
   - Cold: vague or low-intent interest.
6. Score each surviving opportunity out of 100:
   - Intent: 0–30
   - Budget: 0–25
   - Urgency: 0–20
   - Fit: 0–15
   - Engagement: 0–10
7. For Hot and Warm leads, draft a concise personalized reply. Use
   `save_draft` only when the user asks for a persisted Mermail draft or when
   draft storage is useful for review. Never claim a draft was sent.
8. Before any external-effect reply:
   - Show the exact recipient, subject, and full body.
   - Ask for fresh, explicit approval for that specific message.
   - After approval, use `reply_to_email` for a reply or `send_email` for a new
     message, following the owning compose-email skill's contract.
   - Report the actual result. Never silently retry an uncertain send.
9. Give each Hot/Warm lead one next action. Do not create an open-ended polling
   loop or more than one outstanding follow-up action per thread.
10. End with one Deal Board report, sorted by score within each bucket.

## Deal Board format

```text
DEALFLOW REPORT

🔥 HOT
[Name/company] — [opportunity]
Score: [0-100]
Budget: [value or Unknown]
Deadline: [value or Unknown]
Status: [Draft pending approval / Reply sent]
Next action: [one action]

🟡 WARM
...

⚪ COLD
...

Skipped as spam/irrelevant: [count]
```

If a bucket is empty, state that explicitly.

## Scope

This skill does not own Mermail MCP tools. It composes the existing
`mermail-manage-inbox` and `mermail-compose-email` capabilities. It does not
manage calendars, invoices, contracts, payments, workspace administration,
triagers, or third-party apps.

## Examples

- "Analyze my latest Mermail conversations and find genuine business leads."
- "Turn my inbox into a pipeline and draft replies for the best opportunities."
- "Prioritize this week's inbound opportunities and show me what I should reply to."
