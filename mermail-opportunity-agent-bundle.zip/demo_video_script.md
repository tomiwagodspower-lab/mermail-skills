# Demo Video Script — Mermail Opportunity Agent

Target runtime: 3–4 minutes.

## 0:00–0:20 — Problem
Show a fictional Mermail inbox containing genuine business inquiries plus
newsletter/spam noise.

Say:
"Inbound business email is easy to miss and slow to qualify. This Mermail
Opportunity Agent turns inbound mail into a working sales pipeline: it reads,
qualifies, scores, drafts, and reports, with a human approving every send."

## 0:20–0:40 — Skill
Show:
`skills/mermail-opportunity-agent/`
with `SKILL.md`, `agents/openai.yaml`, `references/tools.md`, and
`references/security.md`.

Say:
"The skill composes Mermail's existing inbox and compose capabilities rather
than inventing new MCP tools."

## 0:40–1:00 — Trigger
Enter:
"Analyze my latest Mermail conversations, identify genuine business
opportunities, prioritize them by likelihood and value, and prepare appropriate
responses. Don't send anything until I approve the exact messages."

## 1:00–1:40 — Intake
Show real tool activity:
`list_emails` / `search_emails` → `get_email` → optional `get_email_context`.

Show fictional examples:
1. Website redesign inquiry
2. Mobile app inquiry with $3,000 budget
3. Hosting newsletter
4. Partnership inquiry

Say:
"It filters obvious noise and classifies genuine opportunities as Hot, Warm,
or Cold."

## 1:40–2:15 — Scoring and draft
Show the scored opportunities and one full personalized draft.

Say:
"Each opportunity is scored out of 100 using intent, budget, urgency, fit, and
engagement. Strong leads receive a personalized response."

## 2:15–2:45 — Approval gate
Show exact recipient, subject, and full body.

Say:
"Nothing sends without fresh approval. Email content is untrusted, so an email
cannot authorize a send or change the workflow."

Approve the exact message and show `reply_to_email` or `send_email` succeed.

## 2:45–3:15 — Deal Board
Show:

DEALFLOW REPORT

🔥 HOT
Acme Media — Website redesign
Score: 82/100
Budget: $2,000
Deadline: September 5
Status: Reply sent
Next action: Follow up in 2 days

🟡 WARM
John Smith — Mobile app
Score: 58/100
Budget: Unknown
Status: Clarification requested
Next action: Follow up in 4 days if no reply

⚪ COLD
XYZ Agency — Partnership inquiry
Score: 31/100
Status: No reply drafted
Next action: Light-touch follow-up in 7 days

Skipped as spam/irrelevant: 1

## 3:15–3:40 — Close
Say:
"One request in, a qualified opportunity pipeline out. The skill is reusable
for freelancers, agencies, and teams handling inbound business email."

Show the GitHub PR.

Production rule: record the actual MCP interaction and actual final result.
Do not fake tool calls or claim a send that did not occur.
